import Login from "../src/screens/Login";
export default function LoginRoute() {
  return <Login embedded />;
}
